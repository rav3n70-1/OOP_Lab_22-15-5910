package Fundamentals;

public class HelloWorld {

	public static void main(String[] args) 
	{
		System.out.print("Mehedi Hasan Rohan\n");
		System.out.print("Section- U\n");
		System.out.print("Student Id- 221-15-5910\n");
		System.out.print("Daffodil Internatioal University\n");
	}

}
